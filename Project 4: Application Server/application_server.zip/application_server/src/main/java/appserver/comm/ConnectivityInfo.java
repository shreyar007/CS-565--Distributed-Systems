package appserver.comm;

import java.io.Serializable;

/**
 * Class [ConnectivityInfo] Wraps server connectivity information
 * 
 * @author Dr.-Ing. Wolf-Dieter Otte
 */
public class ConnectivityInfo implements Serializable {

    String host = null;
    int port = 0;
    String name = null;
    
    //setting port 
    public void setPort(int port) {
        this.port = port;
    }
    
    //retreving the port number
    public int getPort() {
        return port;
    }
    
    //getting host address
    public String getHost() {
        return host;
    }
 
    //assigning host address
    public void setHost(String ipAddress) {
        this.host = ipAddress;
    }

    //returning the name
    public String getName() {
        return name;
    }
 
    //assigning the name
    public void setName(String name) {
        this.name = name;
    }
}
