/**
 * Class Fibonacci 
 * 
 * @author Dr.-Ing. Wolf-Dieter Otte
 * @Shreya Balasubramanya Raju , @Sai Greeshmanth Chigurupati , @Goutham Kumar J
 */
package appserver.job.impl;

import appserver.job.Tool;

/**
 * A tool that computes a fibonacci number.
 * @author zane
 */
public class Fibonacci implements Tool
{

    /**
     * The helper that will compute the fibonacci number.
     */
    FibonacciAux helper = null;
    
    /**
     * Compute a fibonacci number, returning the result.
     * @param parameters an Integer fib number to compute.
     * @return fib(n)
     */
    @Override
    public Object go(Object parameters) 
    {
        
        helper = new FibonacciAux( (Integer) parameters );
        
        //calculating fibonacci of a string and printing the result
        System.out.println( "[Fibonacci.go] Calculating fibonacci of " 
        + ((Integer) parameters ).toString() );
        Integer result = helper.getResult();

        System.out.println( "[Fibonacci.go] fib(" 
            + ((Integer) parameters ).toString() + ") Result: " + result.toString() );
        return result;
    }
    
}
