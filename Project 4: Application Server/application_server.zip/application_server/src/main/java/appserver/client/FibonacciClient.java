/**
 * Class FibonacciClient 
 * 
 * @author Dr.-Ing. Wolf-Dieter Otte
 * @Shreya Balasubramanya Raju , @Sai Greeshmanth Chigurupati , @Goutham Kumar J
 */
package appserver.client;

import appserver.comm.Message;
import appserver.comm.MessageTypes;
import appserver.job.Job;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Properties;
import utils.PropertyHandler;

/**
 * A client that submits requests to compute fibonacci numbers to 
 * the server.
 * @author zane
 */
public class FibonacciClient implements MessageTypes, Runnable 
{
    String host = null;
    int port = 0;
    int fibNumber = 0;

    Properties properties;
    
    
    //assigning the serverproperties file and the fibanocci number
    public FibonacciClient( String serverPropertiesFile, int fibNumber )
    {
        try
        {
            //adding the serverproperties file to the handler
            properties = new PropertyHandler( serverPropertiesFile );
            this.fibNumber = fibNumber;
            
            //gets the property of the host i.e ip address
            host = properties.getProperty( "HOST" );
            host = "127.0.0.1";
            //getting port info
            port = Integer.parseInt( properties.getProperty( "PORT" ) );

        }
        catch( Exception ex )
        {
            //printing output for exception case
            System.out.println( "[FibonacciClient.FibonacciClient] Unknown exception "
                + "occurred. ");
            ex.printStackTrace();
        }
    }

    @Override
    public void run()
    {
        try
        {
            //adding new server socket
            Socket server = new Socket( host, port );
            
            //assigning the classString to fibonaccli client
            String classString = "appserver.job.impl.Fibonacci";
            Integer n = new Integer( fibNumber );
            
            //creating a new job with classString and number of numbers
            Job job = new Job( classString, n );
            
            //sending message as JOB_REQUEST to Application Server
            Message message = new Message( JOB_REQUEST, job );
            
            //printing the out[utstream message
            ObjectOutputStream writeToNet = new ObjectOutputStream(server.getOutputStream());
            writeToNet.writeObject(message);
 
            //reading the object from the server 
            ObjectInputStream readFromNet = new ObjectInputStream(server.getInputStream());
            //obtaining the integer result for the process
            
            Integer result = (Integer) readFromNet.readObject();
            //printing the total fibonacci numbers result all at once on the client side
            System.out.println( "fib(" + n.toString() + 
                ") RESULT: " + result );
        }
        catch( Exception ex )
        {
            ex.printStackTrace();
        }
        
    }

    public static void main( String[] args )
    {
        //validating the properties file path
        String propertiesFilePath = "";
        
        //if there is one satellite then the path is fixed to particular satellite
        if( args.length == 1 )
        {
            propertiesFilePath = args[ 0 ];
        }
        else
        {
            //or else obtain from the server properties 
            propertiesFilePath = "../../config/Server.properties";
        }
        
        //creating a new thread
        Thread[] threads = new Thread[ 46 ];
        
        //creating the number of fibonacci's to occour i.e number of threads, here 46
        for( int i = 46; i > 0 ; i-- )
        {
            //assigning idx as decrement count to i 
            int idx = i - 1;
            
            //assigning the properties file path to fibonacci client
            threads[ idx ] = 
            ( new Thread( new FibonacciClient( propertiesFilePath, i ) ) );
            threads[ idx ].start();
        }
        
        //threads in loop
        for( int i = 46; i > 0; i-- )
        {
            int idx = i - 1;
            try
            {
                //joining all the threads 
                threads[ idx ].join();
            }
            catch( InterruptedException e )
            {
                //printing the exception case
                System.out.println( "[FibonacciClient.Main] Interrupted exception " + 
                    "when attempting to join threads."
                );
                e.printStackTrace();
            }
        }
    }
    
}
