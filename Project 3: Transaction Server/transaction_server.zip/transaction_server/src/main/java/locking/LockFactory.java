package locking;

/**
 *
 * @author Shreya , Greeshmanth , Goutham J
 * 
 */


 // A factory to produce locks on-demand.
public class LockFactory 
{
	
	// The type of lock that will be produced by this factory. 
	private final LockType.lockType productionLockType;

	
	// Create a factory that will produce a certain type of lock.
	// @param lockTypeToProduce The type of lock that will be produce by this factory.
	public LockFactory( LockType.lockType lockTypeToProduce )
	{
		this.productionLockType = lockTypeToProduce;	
	}

    
     
    
    //Determine whether this factory produces locks or not  
    
    public boolean isLocking()
    {
        // @return True if this factory produces locks that actually lock objects, false otherwise.
        return this.productionLockType == LockType.lockType.LOCKING_LOCK;
    }

	
	
	public Lock getLock()
	{
		if( this.productionLockType == LockType.lockType.LOCKING_LOCK )
		{
                        // @return An appropriate lock, as determined by the initialization of the factory.
			return new LockingLock();	
		}
                // Retrieve a lock of the type that was set by this factory.
		return new NonLockingLock();
	}
	
}
