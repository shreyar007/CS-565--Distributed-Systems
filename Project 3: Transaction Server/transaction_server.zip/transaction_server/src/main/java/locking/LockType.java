package locking;

/**
 * Describes the lock type of a lock. 
 * A lock can be either two things:
 * - locking: Operations related to concurrency control result in the locking/unlocking of access to resources. 
 * - Non-locking: Operations related to concurrency control
 * result in no-operations
 * @author Shreya , Greeshmanth , Goutham J
 */

public interface LockType 
{
	public enum lockType
	{
		LOCKING_LOCK,
		NON_LOCKING_LOCK
	}
	public lockType getType();
}
