package locking;

/**
 *
 * @author Shreya , Greeshmanth , Goutham J
 * 
 */

import accounts.Account;
import java.util.HashMap;
import java.util.Map;
import transaction.Transaction;



//handles high level locking
public class LockManager 
{
    
    private HashMap<Account,Lock> locks;
    private LockFactory lockCreator;
    //ALTERNATIVE ==> Have each transaction hold its own locks
    //Handles the demands for a lock and their release and aquisition
    
    
    //Constructor of LockManager that determines whether
    public LockManager(boolean applyLocking) 
    {
        
        locks = new HashMap();
        
        //locking should be applied or not.
        if( applyLocking )
        {
            this.lockCreator = new LockFactory( LockType.lockType.LOCKING_LOCK );
        }
        else
        {
             this.lockCreator = new LockFactory( LockType.lockType.NON_LOCKING_LOCK );
        }
        
    }
    
    // High level holds 
    // Set lock / release lock  
    //Seting up locks 
    public void setLock( Account account, Transaction trans, LockMode lockType)
    {
        Lock foundLock = null;
        synchronized (this) 
        {
            foundLock = locks.get( account );

            if( foundLock == null )
            {
                foundLock = lockCreator.getLock();
                foundLock.setAcc( account );

                locks.put( account, foundLock );
                
                //if locking is enabled
                if( lockCreator.isLocking() )
                {
                    trans.log( "[LockManager.setLock] " +
                        toUpperCase(
                            lockModeToString( lockType )
                        ) +
                         " Lock created for account #" +
                        + account.getNumber() 
                    );
                }
                
            }
        }

        foundLock.acquire( trans, lockType );
        trans.addLock(foundLock);
    }
    
    // Used for close transaction 
    public void unsetLock( Transaction trans )
    {
        
        synchronized(this)
        {
            for( Lock l : trans.getLocks() )
            {
                l.release( trans );
            }
        }
        
        //resets transaction locks
        trans.resetLocks();
        trans.log( "[LockManager.unsetLock] unlocking all locks for transaction #" + (trans.getID()));
        
        //LockManager managing locking
        for( Map.Entry<Account,Lock> entry : locks.entrySet() )
        {
            Lock aLock = entry.getValue();
            
            if( aLock.isHeldBy( trans ) )
            {
                trans.log( "[LockManager.unsetLock] found held lock " +
                        toUpperCase(
                        lockModeToString( aLock.getMode() )
                        )
                        + " lock for account #" +
                        (aLock.getAcc().getNumber())
                    );
                
                //if locking is done 
                if( lockCreator.isLocking() )
                {
                    trans.log( "[LockManager.unsetLock] Release " +
                        toUpperCase(
                        lockModeToString( aLock.getMode() )
                        )
                        + " lock for account #" +
                        (aLock.getAcc().getNumber())
                    );
                }
                
                //release transaction
                aLock.release(trans);
                //remove lock
                trans.removeLock(aLock);

            }
        }
        
    }

   
    //Turn a lock mode into a string equivalent
    private String lockModeToString( LockMode mode )
    {
        //The lock mode to get a string for.
        if( mode == LockMode.EMPTY )
        {
            return "empty";
        }
        else if( mode == LockMode.READ )
        {
            return "read";
        }
        return "write";
    }

    //A string representation of the lock mode.
    private String toUpperCase( String in )
    {
        return in.substring(0,1).toUpperCase() + in.substring(1).toLowerCase();
    }
}
