
package locking;

/**
 *
 * @author Shreya , Greeshmanth , Goutham J
 * 
 */

public enum LockMode
{
    // need three different types of locks
    // one for no lock
    EMPTY,
    
    // one for write lock
    WRITE,
    
    // one for read lock
    READ
    
}
