package accounts;

/**
 *
 * @author Shreya , Greeshmanth , Goutham J
 * 
 */


// create an account object
// uses Accountmanager to handle Account data
public class Account 
{
    private int accountNumber;
    private int balance;
    
    //This function keeps track of the account and its corresponding balances
    public Account(int newBalance, int id)
    {
        balance = newBalance;
        accountNumber = id;
    }
    
    //returns account number
    public int getNumber()
    {
        return this.accountNumber;
    }
    
    //Gets account balance
    public int getBalance()
    {
        return this.balance;
    }
    
    //setting balance in accounts
    public void setBalance(int balance)
    {
        this.balance = balance;
    }

    @Override
    public boolean equals( Object other )
    {
        return this.accountNumber == ((Account)other).accountNumber;
    }

    @Override
    public int hashCode()
    {
        return Integer.hashCode( this.accountNumber );
    }
}
