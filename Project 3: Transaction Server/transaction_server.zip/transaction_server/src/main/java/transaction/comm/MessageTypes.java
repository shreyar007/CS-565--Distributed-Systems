package transaction.comm;

/**
 *
 * @author Shreya , Greeshmanth , Goutham J
 * 
 */

//class depicting messagetypes
public interface MessageTypes 
{
    public enum MsgType
	{
            OPEN_TRANSACTION,
            CLOSE_TRANSACTION,
            READ_REQUEST,
            WRITE_REQUEST
	}
	public MsgType getType();
    
}
