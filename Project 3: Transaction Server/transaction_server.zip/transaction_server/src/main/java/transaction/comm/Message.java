package transaction.comm;

import java.io.Serializable;


 
 /**
 *
 * @author Shreya , Greeshmanth , Goutham J
 * 
 */

//Represents the base message that is sent over the network. 
public class Message implements MessageTypes, Serializable
{
    
    // The type of message this is.
    private MsgType type;

    
    // The message's contents.
    private Object[] content;
    
    
    // Argument constructor.
    // @param type What this message will be.
    // @param content The contents of the message that will be sent.
    public Message(MsgType type, Object[] content)
    {
        this.type = type;
        this.content = content;
    }
    
    // @return This message's type.
    public MsgType getType()
    {
        return this.type;
    }
    
 
    // @return This message's content
    public Object[] getContent()
    {
        return this.content;
    }
}
