package transaction_server;

import client.Client;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.PropertyHandler;

/**
 *
 * @author Shreya , Greeshmanth , Goutham J
 * 
 */

//main server class
public class Main 
{
    public static void main(String[] args) 
    {
        String propertiesFile = "General.properties";
        int numTestAccounts = 3; //Number of the accounts in the system
        int maxBalance = 500; //Max balance an account starts at (decides highest possible random transaction value)
        int numTransactions = 3; // Number of random transactons to perform
        int numClients = 3; // Number of client threads made
        int startPort = 2081; //Port number to start at to give client
        int serverPort = 2080;
        
        
        String defaultHost = "localhost"; //default ip of the testing host for the clients
        
        
        //Try to load propety file to replace hard coded defaults
        try
        {
            PropertyHandler propHand = new PropertyHandler(propertiesFile);
            
            //importing the number of accounts from properties file
            numTestAccounts = Integer.parseInt(propHand.getProperty("NUMBER_ACCOUNTS"));
            
            //importing the initial balance from properties file
            maxBalance = Integer.parseInt(propHand.getProperty("INITIAL_BALANCE"));
            
            //number of transactions
            numTransactions = Integer.parseInt(propHand.getProperty("NUMBER_TRANSACTIONS"));
            
            //importing number of clients
            numClients = Integer.parseInt(propHand.getProperty("NUMBER_CLIENTS"));
            
            //choosing client port
            startPort = Integer.parseInt(propHand.getProperty("CLIENT_PORT"));
            
            //choosing server port
            serverPort = Integer.parseInt(propHand.getProperty("SERVER_PORT"));
            
            //assigninglocal host to server
            defaultHost = propHand.getProperty("HOST");
            
        } 
        
        catch (IOException ex)
        {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Property file called "+propertiesFile+" failed to load, switching to defaults");
        }
        
        
        // Create a new Transaction Server
        TransactionServer tranServer = new TransactionServer(defaultHost, serverPort);
        tranServer.start();

    }
    
}
